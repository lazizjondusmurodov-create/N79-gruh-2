# 🔐 FastAPI + PostgreSQL + Next.js — Auth + Todo Tizimi

## 📁 Struktura

```
project/
├── backend/
│   ├── main.py            ← FastAPI app
│   ├── database.py        ← PostgreSQL ulanish
│   ├── models.py          ← User + Todo modellari
│   ├── schemas.py         ← Pydantic validatsiya
│   ├── auth.py            ← JWT + bcrypt
│   ├── routes/
│   │   ├── auth.py        ← Register, Login, Logout, Me
│   │   └── todos.py       ← Todo CRUD
│   ├── requirements.txt
│   └── .env.example
│
└── frontend/
    ├── app/
    │   ├── login/         ← Login sahifasi
    │   ├── register/      ← Register sahifasi (parol kuchi, tasdiq)
    │   ├── dashboard/     ← Asosiy sahifa
    │   └── todos/         ← Todo CRUD sahifasi
    ├── context/
    │   └── AuthContext.tsx ← Global auth holati
    ├── lib/
    │   ├── api.ts         ← Fetch yordamchi
    │   ├── todos.ts       ← Todo API funksiyalari
    │   └── types.ts       ← TypeScript interfeyslari
    └── middleware.ts      ← Himoyalangan routelar
```

---

## 🌐 API Endpointlar

### Auth
| Method | URL              | Tavsif                      |
|--------|------------------|-----------------------------|
| POST   | /auth/register   | Ro'yxatdan o'tish           |
| POST   | /auth/login      | Kirish                      |
| GET    | /auth/me         | Profil (token kerak)        |
| POST   | /auth/logout     | Chiqish                     |

### Todos (barchasi token talab qiladi)
| Method | URL                    | Tavsif                |
|--------|------------------------|-----------------------|
| GET    | /todos/                | Barcha todolar        |
| POST   | /todos/                | Yangi todo yaratish   |
| GET    | /todos/{id}            | Bitta todo            |
| PUT    | /todos/{id}            | Todo yangilash        |
| PATCH  | /todos/{id}/toggle     | Bajarildi toggle      |
| DELETE | /todos/{id}            | Todo o'chirish        |

---

## 🚀 Ishga tushirish

### Backend
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # DATABASE_URL va SECRET_KEY yozing
uvicorn main:app --reload
```

### Frontend
```bash
cd frontend
npm install
cp .env.local.example .env.local
npm run dev
```

### Swagger UI (API test)
http://localhost:8000/docs

---

## 🔄 Oqim

```
/register  →  JWT token  →  /dashboard  →  /todos
/login     →  JWT token  →  /dashboard  →  /todos
/todos     →  CRUD (Create, Read, Update, Delete, Toggle)
```
