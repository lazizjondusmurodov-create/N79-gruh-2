"use client";
import { useState } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";

export default function LoginPage() {
  const { login }           = useAuth();
  const [email, setEmail]   = useState("");
  const [password, setPass] = useState("");
  const [error, setError]   = useState("");
  const [loading, setLoad]  = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoad(true);
    try {
      await login(email, password);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoad(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <h1>Kirish</h1>

        {error && <p className="error">{error}</p>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="email@example.com"
              required
            />
          </div>

          <div className="field">
            <label>Parol</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPass(e.target.value)}
              placeholder="********"
              required
            />
          </div>

          <button type="submit" disabled={loading}>
            {loading ? "Kirish..." : "Kirish"}
          </button>
        </form>

        <p>
          Akkaunt yo'qmi? <Link href="/register">Ro'yxatdan o'ting</Link>
        </p>
      </div>
    </div>
  );
}
