"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import {
  fetchTodos,
  createTodo,
  updateTodo,
  toggleTodo,
  deleteTodo,
} from "@/lib/todos";
import { Todo } from "@/lib/types";

type Filter = "all" | "active" | "done";

export default function TodosPage() {
  const { user, loading: authLoading, logout } = useAuth();
  const router = useRouter();

  const [todos, setTodos]           = useState<Todo[]>([]);
  const [filter, setFilter]         = useState<Filter>("all");
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState("");

  // Yangi todo form
  const [newTitle, setNewTitle]     = useState("");
  const [newDesc, setNewDesc]       = useState("");
  const [creating, setCreating]     = useState(false);
  const [showForm, setShowForm]     = useState(false);

  // Tahrirlash
  const [editId, setEditId]         = useState<number | null>(null);
  const [editTitle, setEditTitle]   = useState("");
  const [editDesc, setEditDesc]     = useState("");
  const [saving, setSaving]         = useState(false);

  // Auth tekshirish
  useEffect(() => {
    if (!authLoading && !user) router.push("/login");
  }, [user, authLoading]);

  // Todolarni yuklash
  useEffect(() => {
    if (!user) return;
    loadTodos();
  }, [user]);

  async function loadTodos() {
    setLoading(true);
    setError("");
    try {
      const data = await fetchTodos();
      setTodos(data);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  // ─── CREATE ──────────────────────────────────────────────
  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!newTitle.trim()) return;
    setCreating(true);
    try {
      const todo = await createTodo({
        title: newTitle.trim(),
        description: newDesc.trim() || undefined,
      });
      setTodos([todo, ...todos]);
      setNewTitle("");
      setNewDesc("");
      setShowForm(false);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setCreating(false);
    }
  }

  // ─── TOGGLE ──────────────────────────────────────────────
  async function handleToggle(id: number) {
    try {
      const updated = await toggleTodo(id);
      setTodos(todos.map((t) => (t.id === id ? updated : t)));
    } catch (e: any) {
      setError(e.message);
    }
  }

  // ─── EDIT START ───────────────────────────────────────────
  function startEdit(todo: Todo) {
    setEditId(todo.id);
    setEditTitle(todo.title);
    setEditDesc(todo.description || "");
  }

  // ─── SAVE EDIT ────────────────────────────────────────────
  async function handleSaveEdit(id: number) {
    if (!editTitle.trim()) return;
    setSaving(true);
    try {
      const updated = await updateTodo(id, {
        title: editTitle.trim(),
        description: editDesc.trim() || undefined,
      });
      setTodos(todos.map((t) => (t.id === id ? updated : t)));
      setEditId(null);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  // ─── DELETE ──────────────────────────────────────────────
  async function handleDelete(id: number) {
    if (!confirm("Bu todoni o'chirishni xohlaysizmi?")) return;
    try {
      await deleteTodo(id);
      setTodos(todos.filter((t) => t.id !== id));
    } catch (e: any) {
      setError(e.message);
    }
  }

  // ─── FILTER ──────────────────────────────────────────────
  const filtered = todos.filter((t) => {
    if (filter === "active") return !t.is_done;
    if (filter === "done")   return t.is_done;
    return true;
  });

  const doneCount   = todos.filter((t) => t.is_done).length;
  const activeCount = todos.filter((t) => !t.is_done).length;

  if (authLoading) return <div className="page-center">⏳ Yuklanmoqda...</div>;
  if (!user)       return null;

  return (
    <div className="todo-page">
      {/* ── Header ─────────────────────────────────────── */}
      <header className="todo-header">
        <div className="todo-header-left">
          <h1>✅ Todo App</h1>
          <span className="user-badge">👤 {user.name}</span>
        </div>
        <div className="todo-header-right">
          <a href="/dashboard" className="nav-link">Dashboard</a>
          <button onClick={logout} className="logout-btn">Chiqish</button>
        </div>
      </header>

      <div className="todo-content">
        {/* ── Stats ─────────────────────────────────────── */}
        <div className="stats-row">
          <div className="stat-card">
            <span className="stat-num">{todos.length}</span>
            <span className="stat-label">Jami</span>
          </div>
          <div className="stat-card active">
            <span className="stat-num">{activeCount}</span>
            <span className="stat-label">Aktiv</span>
          </div>
          <div className="stat-card done">
            <span className="stat-num">{doneCount}</span>
            <span className="stat-label">Bajarildi</span>
          </div>
        </div>

        {/* ── Add button & form ──────────────────────────── */}
        <div className="add-section">
          {!showForm ? (
            <button className="add-btn" onClick={() => setShowForm(true)}>
              + Yangi Todo
            </button>
          ) : (
            <form className="todo-form" onSubmit={handleCreate}>
              <h3>Yangi Todo</h3>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Todo sarlavhasi *"
                required
                autoFocus
              />
              <textarea
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Tavsif (ixtiyoriy)"
                rows={3}
              />
              <div className="form-btns">
                <button type="submit" disabled={creating} className="save-btn">
                  {creating ? "Saqlanmoqda..." : "✅ Saqlash"}
                </button>
                <button
                  type="button"
                  className="cancel-btn"
                  onClick={() => { setShowForm(false); setNewTitle(""); setNewDesc(""); }}
                >
                  Bekor qilish
                </button>
              </div>
            </form>
          )}
        </div>

        {error && <div className="error-banner">⚠️ {error}</div>}

        {/* ── Filter tabs ────────────────────────────────── */}
        <div className="filter-tabs">
          {(["all", "active", "done"] as Filter[]).map((f) => (
            <button
              key={f}
              className={`filter-tab ${filter === f ? "active" : ""}`}
              onClick={() => setFilter(f)}
            >
              {f === "all" ? "Barchasi" : f === "active" ? "Aktiv" : "Bajarildi"}
            </button>
          ))}
        </div>

        {/* ── Todo List ──────────────────────────────────── */}
        {loading ? (
          <div className="page-center">⏳ Yuklanmoqda...</div>
        ) : filtered.length === 0 ? (
          <div className="empty-state">
            <span className="empty-icon">📭</span>
            <p>
              {filter === "all"
                ? "Hali hech qanday todo yo'q. Yangi todo qo'shing!"
                : filter === "active"
                ? "Barcha todolar bajarilgan!"
                : "Bajarilgan todolar yo'q"}
            </p>
          </div>
        ) : (
          <ul className="todo-list">
            {filtered.map((todo) => (
              <li key={todo.id} className={`todo-item ${todo.is_done ? "done" : ""}`}>
                {editId === todo.id ? (
                  /* ── Edit mode ── */
                  <div className="edit-form">
                    <input
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      placeholder="Sarlavha"
                      autoFocus
                    />
                    <textarea
                      value={editDesc}
                      onChange={(e) => setEditDesc(e.target.value)}
                      placeholder="Tavsif"
                      rows={2}
                    />
                    <div className="form-btns">
                      <button
                        className="save-btn small"
                        onClick={() => handleSaveEdit(todo.id)}
                        disabled={saving}
                      >
                        {saving ? "..." : "✅ Saqlash"}
                      </button>
                      <button
                        className="cancel-btn small"
                        onClick={() => setEditId(null)}
                      >
                        Bekor
                      </button>
                    </div>
                  </div>
                ) : (
                  /* ── View mode ── */
                  <>
                    <div className="todo-left">
                      <button
                        className={`check-btn ${todo.is_done ? "checked" : ""}`}
                        onClick={() => handleToggle(todo.id)}
                        title={todo.is_done ? "Bajarilmadi deb belgilash" : "Bajarildi deb belgilash"}
                      >
                        {todo.is_done ? "✅" : "⬜"}
                      </button>
                      <div className="todo-text">
                        <p className={`todo-title ${todo.is_done ? "strikethrough" : ""}`}>
                          {todo.title}
                        </p>
                        {todo.description && (
                          <p className="todo-desc">{todo.description}</p>
                        )}
                        <p className="todo-date">
                          {new Date(todo.created_at).toLocaleDateString("uz-UZ")}
                        </p>
                      </div>
                    </div>
                    <div className="todo-actions">
                      <button
                        className="edit-btn"
                        onClick={() => startEdit(todo)}
                        title="Tahrirlash"
                      >
                        ✏️
                      </button>
                      <button
                        className="delete-btn"
                        onClick={() => handleDelete(todo.id)}
                        title="O'chirish"
                      >
                        🗑️
                      </button>
                    </div>
                  </>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
