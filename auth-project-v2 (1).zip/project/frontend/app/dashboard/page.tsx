"use client";
import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import Link from "next/link";

export default function DashboardPage() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.push("/login");
  }, [user, loading]);

  if (loading) return <div className="page-center">⏳ Yuklanmoqda...</div>;
  if (!user)   return null;

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <h1>🏠 Dashboard</h1>
        <button onClick={logout} className="logout-btn">Chiqish</button>
      </div>

      <div className="user-card">
        <h2>Xush kelibsiz, {user.name}! 👋</h2>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>ID:</strong> {user.id}</p>
        <p>
          <strong>Holat:</strong>{" "}
          <span className={user.is_active ? "active" : "inactive"}>
            {user.is_active ? "✅ Faol" : "❌ Faol emas"}
          </span>
        </p>
      </div>

      <div className="dashboard-nav">
        <Link href="/todos" className="nav-card">
          <span className="nav-icon">✅</span>
          <div>
            <p className="nav-title">Todo Ro'yxati</p>
            <p className="nav-sub">Vazifalarni boshqarish</p>
          </div>
          <span className="nav-arrow">→</span>
        </Link>
      </div>
    </div>
  );
}
