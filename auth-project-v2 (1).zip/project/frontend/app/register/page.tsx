"use client";
import { useState } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";

export default function RegisterPage() {
  const { register }            = useAuth();
  const [name, setName]         = useState("");
  const [email, setEmail]       = useState("");
  const [password, setPass]     = useState("");
  const [confirm, setConfirm]   = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError]       = useState("");
  const [loading, setLoad]      = useState(false);

  const validate = () => {
    if (!name.trim())           return "Ism bo'sh bo'lmasligi kerak";
    if (name.trim().length < 2) return "Ism kamida 2 ta harf bo'lishi kerak";
    if (password.length < 6)    return "Parol kamida 6 ta belgidan iborat bo'lishi kerak";
    if (password !== confirm)   return "Parollar mos kelmadi";
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const validationError = validate();
    if (validationError) { setError(validationError); return; }

    setLoad(true);
    try {
      await register(name.trim(), email, password);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoad(false);
    }
  };

  const strength = password.length === 0 ? 0
    : password.length < 6  ? 1
    : password.length < 10 ? 2
    : 3;

  const strengthLabel = ["", "Zaif 🔴", "O'rtacha 🟡", "Kuchli 🟢"][strength];
  const strengthColor = ["", "#ef4444", "#f59e0b", "#22c55e"][strength];

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-logo">📝</div>
        <h1>Ro'yxatdan o'tish</h1>
        <p className="auth-subtitle">Akkaunt yarating va boshlang</p>

        {error && (
          <div className="error">
            <span>⚠️</span> {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label>To'liq ism</label>
            <div className="input-wrap">
              <span className="input-icon">👤</span>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ismingiz Familiyangiz"
                required
              />
            </div>
          </div>

          <div className="field">
            <label>Email</label>
            <div className="input-wrap">
              <span className="input-icon">✉️</span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="email@example.com"
                required
              />
            </div>
          </div>

          <div className="field">
            <label>Parol</label>
            <div className="input-wrap">
              <span className="input-icon">🔑</span>
              <input
                type={showPass ? "text" : "password"}
                value={password}
                onChange={(e) => setPass(e.target.value)}
                placeholder="Kamida 6 belgi"
                required
              />
              <button
                type="button"
                className="eye-btn"
                onClick={() => setShowPass(!showPass)}
              >
                {showPass ? "🙈" : "👁️"}
              </button>
            </div>
            {password && (
              <p className="strength-text" style={{ color: strengthColor }}>
                {strengthLabel}
              </p>
            )}
          </div>

          <div className="field">
            <label>Parolni tasdiqlang</label>
            <div className="input-wrap">
              <span className="input-icon">🔒</span>
              <input
                type={showPass ? "text" : "password"}
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                placeholder="Parolni qaytaring"
                required
              />
              {confirm && (
                <span className="check-icon">
                  {password === confirm ? "✅" : "❌"}
                </span>
              )}
            </div>
          </div>

          <button type="submit" disabled={loading} className="submit-btn">
            {loading ? (
              <span className="loading-spinner">⏳ Saqlanmoqda...</span>
            ) : (
              "Ro'yxatdan o'tish →"
            )}
          </button>
        </form>

        <p className="auth-footer">
          Akkaunt bormi? <Link href="/login">Kirish</Link>
        </p>
      </div>
    </div>
  );
}
