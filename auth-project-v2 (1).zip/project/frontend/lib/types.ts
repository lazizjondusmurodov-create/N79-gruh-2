export interface Todo {
  id: number;
  title: string;
  description: string | null;
  is_done: boolean;
  user_id: number;
  created_at: string;
  updated_at: string | null;
}

export interface TodoCreate {
  title: string;
  description?: string;
}

export interface TodoUpdate {
  title?: string;
  description?: string;
  is_done?: boolean;
}
