import { apiFetch } from "./api";
import { Todo, TodoCreate, TodoUpdate } from "./types";

// Barcha todolarni olish
export async function fetchTodos(): Promise<Todo[]> {
  const res = await apiFetch("/todos/");
  if (!res.ok) throw new Error("Todolarni yuklab bo'lmadi");
  return res.json();
}

// Yangi todo yaratish
export async function createTodo(data: TodoCreate): Promise<Todo> {
  const res = await apiFetch("/todos/", {
    method: "POST",
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || "Todo yaratib bo'lmadi");
  }
  return res.json();
}

// Todo yangilash
export async function updateTodo(id: number, data: TodoUpdate): Promise<Todo> {
  const res = await apiFetch(`/todos/${id}`, {
    method: "PUT",
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || "Todo yangilab bo'lmadi");
  }
  return res.json();
}

// Bajarildi/Bajarilmadi toggle
export async function toggleTodo(id: number): Promise<Todo> {
  const res = await apiFetch(`/todos/${id}/toggle`, { method: "PATCH" });
  if (!res.ok) throw new Error("Toggle xatolik");
  return res.json();
}

// Todo o'chirish
export async function deleteTodo(id: number): Promise<void> {
  const res = await apiFetch(`/todos/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Todo o'chirib bo'lmadi");
}
