from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import Base, engine
from routes.auth import router as auth_router
from routes.todos import router as todos_router

# DB jadvallarini avtomatik yaratish
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Auth + Todo API",
    description="FastAPI + PostgreSQL | Authentication & Todo CRUD",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(todos_router)


@app.get("/")
def root():
    return {"message": "Auth + Todo API ishlayapti ✅"}
