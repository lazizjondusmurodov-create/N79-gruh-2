from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from database import get_db
from models import Todo, User
from schemas import TodoCreate, TodoUpdate, TodoResponse
from auth import get_current_user

router = APIRouter(prefix="/todos", tags=["Todos"])


# ─── CREATE — Yangi todo ────────────────────────────────────────────────────
@router.post("/", response_model=TodoResponse, status_code=201)
def create_todo(
    body: TodoCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    todo = Todo(
        title       = body.title,
        description = body.description,
        user_id     = current_user.id,
    )
    db.add(todo)
    db.commit()
    db.refresh(todo)
    return todo


# ─── READ ALL — Barcha todolar ──────────────────────────────────────────────
@router.get("/", response_model=List[TodoResponse])
def get_todos(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    todos = (
        db.query(Todo)
        .filter(Todo.user_id == current_user.id)
        .order_by(Todo.created_at.desc())
        .all()
    )
    return todos


# ─── READ ONE — Bitta todo ──────────────────────────────────────────────────
@router.get("/{todo_id}", response_model=TodoResponse)
def get_todo(
    todo_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    todo = db.query(Todo).filter(
        Todo.id == todo_id,
        Todo.user_id == current_user.id
    ).first()

    if not todo:
        raise HTTPException(status_code=404, detail="Todo topilmadi")
    return todo


# ─── UPDATE — Tahrirlash ────────────────────────────────────────────────────
@router.put("/{todo_id}", response_model=TodoResponse)
def update_todo(
    todo_id: int,
    body: TodoUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    todo = db.query(Todo).filter(
        Todo.id == todo_id,
        Todo.user_id == current_user.id
    ).first()

    if not todo:
        raise HTTPException(status_code=404, detail="Todo topilmadi")

    if body.title is not None:
        todo.title = body.title
    if body.description is not None:
        todo.description = body.description
    if body.is_done is not None:
        todo.is_done = body.is_done

    db.commit()
    db.refresh(todo)
    return todo


# ─── TOGGLE — Bajarildi/Bajarilmadi ─────────────────────────────────────────
@router.patch("/{todo_id}/toggle", response_model=TodoResponse)
def toggle_todo(
    todo_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    todo = db.query(Todo).filter(
        Todo.id == todo_id,
        Todo.user_id == current_user.id
    ).first()

    if not todo:
        raise HTTPException(status_code=404, detail="Todo topilmadi")

    todo.is_done = not todo.is_done
    db.commit()
    db.refresh(todo)
    return todo


# ─── DELETE — O'chirish ──────────────────────────────────────────────────────
@router.delete("/{todo_id}", status_code=204)
def delete_todo(
    todo_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    todo = db.query(Todo).filter(
        Todo.id == todo_id,
        Todo.user_id == current_user.id
    ).first()

    if not todo:
        raise HTTPException(status_code=404, detail="Todo topilmadi")

    db.delete(todo)
    db.commit()
